module.exports = {
  config: {
    credits: "MR DEVIL",
    name: 'shareid',
    aliases: ['sharecontact', 'sid'],
    description: 'Share the contact card of a user',
    usage: 'shareid [mention/reply/uid]',
    category: 'Utility',
    prefix: true
  },

  async run({ api, event, args, send }) {
    const { threadID, messageID, senderID, messageReply, mentions } = event;
    let uid;

    if (messageReply) {
      uid = messageReply.senderID;
    } else if (mentions && Object.keys(mentions).length > 0) {
      uid = Object.keys(mentions)[0];
    } else if (args[0] && /^\d+$/.test(args[0])) {
      uid = args[0];
    } else {
      uid = senderID;
    }

    try {
      const info = await api.getUserInfo(uid);
      const name = info[uid].name;
      const msg = `👤 Contact Card\n━━━━━━━━━━━━\n✏️ Name: ${name}\n🔢 ID: ${uid}`;
      return api.shareContact(msg, uid, threadID);
    } catch (error) {
      return send.reply(`⚠️ Failed: ${error.message}`);
    }
  }
};
